#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class AloTuneAudioProcessorEditor final : public juce::AudioProcessorEditor
{
public:
    explicit AloTuneAudioProcessorEditor(AloTuneAudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    AloTuneAudioProcessor& processor;
    juce::Slider depth, bend;
    juce::ComboBox root, mode;
    juce::ToggleButton mpe;
    juce::Label title, status;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SliderAttachment> depthA, bendA;
    std::unique_ptr<ComboAttachment> rootA, modeA;
    std::unique_ptr<ButtonAttachment> mpeA;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AloTuneAudioProcessorEditor)
};
