#include "PluginProcessor.h"
#include "PluginEditor.h"

AloTuneAudioProcessor::AloTuneAudioProcessor()
 : AudioProcessor(BusesProperties()),
   parameters(*this, nullptr, "PARAMETERS", createParameterLayout()) {}

juce::AudioProcessorValueTreeState::ParameterLayout AloTuneAudioProcessor::createParameterLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> p;
    p.push_back(std::make_unique<AudioParameterFloat>("depth", "JI Amount", NormalisableRange<float>(0.0f, 1.0f, 0.001f), 1.0f));
    p.push_back(std::make_unique<AudioParameterInt>("root", "Root (0=Auto, 1=C ... 12=B)", 0, 12, 0));
    p.push_back(std::make_unique<AudioParameterChoice>("mode", "Scale", StringArray{"Major / chromatic", "Minor"}, 0));
    p.push_back(std::make_unique<AudioParameterFloat>("bend", "Pitch Bend Range (semitones)", NormalisableRange<float>(1.0f, 48.0f, 1.0f), 2.0f));
    p.push_back(std::make_unique<AudioParameterBool>("mpe", "MPE Output", true));
    return { p.begin(), p.end() };
}

int AloTuneAudioProcessor::allocateChannel()
{
    // MPE lower zone: channel 1 is master; member channels are 2..16.
    for (int c = 2; c <= 16; ++c)
        if (! channelBusy[(size_t)c - 1]) { channelBusy[(size_t)c - 1] = true; return c; }
    return 0;
}

float AloTuneAudioProcessor::centsForNote(int note, int root, int temperament) const
{
    // Ratios for each chromatic degree, expressed as cents in one octave.
    // Major/minor modes constrain chord-root interpretation, not incoming notes.
    static constexpr float ji[12] = { 0.0f, 111.731f, 203.910f, 315.641f, 386.314f, 498.045f,
                                       590.224f, 701.955f, 813.686f, 884.359f, 996.090f, 1088.269f };
    static constexpr float jiMinor[12] = { 0.0f, 111.731f, 203.910f, 315.641f, 386.314f, 498.045f,
                                            590.224f, 701.955f, 813.686f, 884.359f, 1017.596f, 1088.269f };
    int degree = (note - root) % 12; if (degree < 0) degree += 12;
    const float target = temperament == 2 ? jiMinor[degree] : ji[degree];
    const float equal = 100.0f * (float)degree;
    return target - equal;
}

void AloTuneAudioProcessor::clearAll(juce::MidiBuffer& out, int sample)
{
    for (auto& v : voices) if (v.used) {
        out.addEvent(juce::MidiMessage::noteOff(v.outChannel, v.outNote), sample);
        out.addEvent(juce::MidiMessage::pitchWheel(v.outChannel, 8192), sample);
        channelBusy[(size_t)v.outChannel - 1] = false; v.used = false;
    }
    activeCount.store(0);
}

void AloTuneAudioProcessor::processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    for (int ch = 0; ch < audio.getNumChannels(); ++ch) audio.clear(ch, 0, audio.getNumSamples());
    juce::MidiBuffer output;
    const float depth = parameters.getRawParameterValue("depth")->load();
    const int selectedRoot = (int)parameters.getRawParameterValue("root")->load();
    const int mode = (int)parameters.getRawParameterValue("mode")->load();
    const float bendRange = juce::jmax(1.0f, parameters.getRawParameterValue("bend")->load());
    const bool mpe = parameters.getRawParameterValue("mpe")->load() > 0.5f;

    // Auto root is the lowest currently held note. This is intentionally simple and
    // predictable; explicit root selection is recommended for inversions/pedal tones.
    for (const auto metadata : midi)
    {
        const auto msg = metadata.getMessage(); const int pos = metadata.samplePosition;
        if (msg.isAllNotesOff() || msg.isAllSoundOff()) { clearAll(output, pos); continue; }
        if (msg.isNoteOn()) {
            int root = msg.getNoteNumber();
            if (selectedRoot > 0) root = (selectedRoot - 1) + 12 * (msg.getNoteNumber() / 12);
            else for (const auto& v : voices) if (v.used) root = juce::jmin(root, v.sourceNote);
            auto it = std::find_if(voices.begin(), voices.end(), [] (const Voice& v) { return !v.used; });
            if (it == voices.end()) continue;
            int outChannel = mpe ? allocateChannel() : msg.getChannel();
            if (outChannel == 0) continue;
            const float cents = centsForNote(msg.getNoteNumber(), root, mode) * depth;
            const float normalized = juce::jlimit(-1.0f, 1.0f, cents / (bendRange * 100.0f));
            const int wheel = juce::jlimit(0, 16383, (int)std::round(8192.0f + normalized * 8192.0f));
            if (mpe) output.addEvent(juce::MidiMessage::pitchWheel(outChannel, wheel), pos);
            output.addEvent(juce::MidiMessage::noteOn(outChannel, msg.getNoteNumber(), msg.getFloatVelocity()), pos);
            *it = { msg.getChannel(), msg.getNoteNumber(), outChannel, msg.getNoteNumber(), true };
            // Re-evaluate all held voices when the chord changes. This makes the
            // tuning genuinely adaptive rather than freezing the first note's context.
            int chordRoot = selectedRoot > 0
                ? (selectedRoot - 1) + 12 * (msg.getNoteNumber() / 12)
                : msg.getNoteNumber();
            if (selectedRoot == 0)
                for (const auto& v : voices) if (v.used) chordRoot = juce::jmin(chordRoot, v.sourceNote);
            if (mpe)
                for (const auto& v : voices) if (v.used) {
                    const float voiceCents = centsForNote(v.sourceNote, chordRoot, mode) * depth;
                    const float voiceNorm = juce::jlimit(-1.0f, 1.0f, voiceCents / (bendRange * 100.0f));
                    const int voiceWheel = juce::jlimit(0, 16383, (int)std::round(8192.0f + voiceNorm * 8192.0f));
                    output.addEvent(juce::MidiMessage::pitchWheel(v.outChannel, voiceWheel), pos);
                }
        } else if (msg.isNoteOff()) {
            auto it = std::find_if(voices.begin(), voices.end(), [&] (const Voice& v) { return v.used && v.sourceChannel == msg.getChannel() && v.sourceNote == msg.getNoteNumber(); });
            if (it != voices.end()) {
                output.addEvent(juce::MidiMessage::noteOff(it->outChannel, it->outNote, msg.getFloatVelocity()), pos);
                if (mpe) output.addEvent(juce::MidiMessage::pitchWheel(it->outChannel, 8192), pos);
                channelBusy[(size_t)it->outChannel - 1] = false; it->used = false;
            }
        } else if (msg.isController() && (msg.getControllerNumber() == 120 || msg.getControllerNumber() == 123)) {
            clearAll(output, pos);
        } else if (msg.isPitchWheel() || msg.isAftertouch() || msg.isChannelPressure()) {
            // Pass expressive input through on the original channel; MPE pitch is generated here.
            if (!mpe) output.addEvent(msg, pos);
        } else {
            output.addEvent(msg, pos);
        }
    }
    int count = 0; for (const auto& v : voices) if (v.used) ++count; activeCount.store(count);
    midi.swapWith(output);
}

void AloTuneAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{ auto state = parameters.copyState(); std::unique_ptr<juce::XmlElement> xml(state.createXml()); copyXmlToBinary(*xml, dest); }
void AloTuneAudioProcessor::setStateInformation(const void* data, int size)
{ std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size)); if (xml && xml->hasTagName(parameters.state.getType())) parameters.replaceState(juce::ValueTree::fromXml(*xml)); }
juce::AudioProcessorEditor* AloTuneAudioProcessor::createEditor() { return new AloTuneAudioProcessorEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new AloTuneAudioProcessor(); }
