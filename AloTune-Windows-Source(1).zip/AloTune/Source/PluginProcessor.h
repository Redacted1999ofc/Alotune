#pragma once
#include <JuceHeader.h>
#include <array>

class AloTuneAudioProcessor final : public juce::AudioProcessor
{
public:
    AloTuneAudioProcessor();
    ~AloTuneAudioProcessor() override = default;

    void prepareToPlay(double, int) override {}
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override { return true; }
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "AloTune"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return true; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::AudioProcessorValueTreeState parameters;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    int activeNoteCount() const noexcept { return activeCount.load(); }

private:
    struct Voice { int sourceChannel=0, sourceNote=-1, outChannel=0, outNote=-1; bool used=false; };
    std::array<Voice, 256> voices{};
    std::array<bool, 16> channelBusy{};
    std::atomic<int> activeCount { 0 };
    int allocateChannel();
    float centsForNote(int midiNote, int rootNote, int temperament) const;
    void clearAll(juce::MidiBuffer& output, int sample);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AloTuneAudioProcessor)
};
