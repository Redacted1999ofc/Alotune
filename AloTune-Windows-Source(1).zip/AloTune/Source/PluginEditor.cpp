#include "PluginEditor.h"
AloTuneAudioProcessorEditor::AloTuneAudioProcessorEditor(AloTuneAudioProcessor& p) : AudioProcessorEditor(&p), processor(p)
{
    setSize(440, 330);
    title.setText("ALOTUNE  /  ADAPTIVE JUST INTONATION", juce::dontSendNotification); title.setFont(juce::Font(19.0f, juce::Font::bold)); addAndMakeVisible(title);
    auto setup = [] (juce::Slider& s, const juce::String& name) { s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag); s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 90, 22); s.setName(name); };
    setup(depth, "JI AMOUNT"); setup(bend, "BEND RANGE"); addAndMakeVisible(depth); addAndMakeVisible(bend);
    root.addItem("Auto (lowest held note)", 1); const char* names[] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    for (int i=0;i<12;++i) root.addItem(names[i], i+2); addAndMakeVisible(root);
    mode.addItem("Major / chromatic",1); mode.addItem("Minor seventh variant",2); addAndMakeVisible(mode);
    mpe.setButtonText("MPE output (recommended for Vital)"); addAndMakeVisible(mpe);
    status.setText("Route MIDI through AloTune, then into Vital. Enable MPE in Vital.", juce::dontSendNotification); status.setFont(juce::Font(12.0f)); addAndMakeVisible(status);
    depthA = std::make_unique<SliderAttachment>(p.parameters,"depth",depth); bendA = std::make_unique<SliderAttachment>(p.parameters,"bend",bend);
    rootA = std::make_unique<ComboAttachment>(p.parameters,"root",root); modeA = std::make_unique<ComboAttachment>(p.parameters,"mode",mode);
    mpeA = std::make_unique<ButtonAttachment>(p.parameters,"mpe",mpe);
}
void AloTuneAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff11131a)); g.setColour(juce::Colour(0xff6ee7c2)); g.fillRoundedRectangle(14.0f, 14.0f, 412.0f, 3.0f, 1.5f);
    g.setColour(juce::Colour(0xff252a36)); g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(8.0f), 12.0f, 1.0f);
}
void AloTuneAudioProcessorEditor::resized()
{
    title.setBounds(24,25,395,30); depth.setBounds(35,75,145,145); bend.setBounds(255,75,145,145);
    root.setBounds(35,235,175,28); mode.setBounds(230,235,175,28); mpe.setBounds(35,275,270,24); status.setBounds(35,300,380,22);
}
