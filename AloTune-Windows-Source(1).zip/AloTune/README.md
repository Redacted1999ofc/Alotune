# AloTune 0.1 — Adaptive Just Intonation MIDI effect

A JUCE-based VST3 MIDI effect and standalone target for Windows 10 x64. It retunes incoming MIDI notes by emitting per-note pitch bends on MPE member channels (2–16), then sends the notes onward. It does **not** process audio and does not clone a proprietary preset or sound engine; it changes note intonation before Vital synthesizes the sound.

## Important: Vital setup
1. In Vital, enable its MPE support / MPE mode and set the pitch-bend range to match AloTune (default 2 semitones).
2. Insert AloTune as a MIDI effect **before** Vital in a DAW that supports MIDI-effect routing and VST3 MIDI output.
3. Enable `MPE output` in AloTune. Start with `JI Amount` at 100%.
4. Choose a fixed root if you have inversions, pedal tones, or a bass note that should not define the chord. `Auto` uses the lowest currently held note.

Host support for VST3 MIDI-effect routing varies. Some hosts do not expose MIDI output from VST3 effects or do not allow a MIDI effect directly before an instrument. In those hosts, use a MIDI routing track/virtual MIDI port if available. The standalone target is a MIDI-device utility shell and cannot automatically inject MIDI into Vital without a virtual MIDI loopback driver (for example loopMIDI).

## Tracktion Waveform 14 setup

Waveform documents MIDI effects as processors that modify MIDI and must be placed before the virtual instrument. For this project, use one instrument track with the chain ordered left-to-right as:

`MIDI input / MIDI clip -> AloTune -> Vital -> audio level / output`

1. Open Waveform 14 and create an instrument track.
2. Add AloTune to the track plugin chain before Vital. If Waveform does not list AloTune as a MIDI effect after scanning, confirm the VST3 build is installed and rescan; host support for third-party VST3 MIDI-effect output can vary.
3. Add Vital after AloTune and load your existing Aloboi preset.
4. In Vital, enable MPE/per-note pitch handling if available in your version, and set its pitch-bend range to the same value as AloTune (2 semitones by default).
5. In AloTune, enable MPE Output. Use Auto root for simple root-position chords, or choose a fixed root when the bass note/inversion should not define the tuning centre.
6. Play a held chord and verify that each note responds independently. If Waveform routes the plugin MIDI but Vital does not respond to per-note bends, check Vital's MPE setting and bend range first.

Waveform's MIDI-effects guide: https://tracktion.github.io/waveform_manual/14.0.50/midi-effects/

**Standalone note:** the standalone target is not a replacement for Vital or a self-contained synth. It is useful as a MIDI utility/test build, but sending its retuned MIDI into Vital as a separate application requires a virtual MIDI loopback device (for example, loopMIDI) and matching input/output routing. The in-track VST3 route is the preferred Waveform workflow.

## Easiest option: build automatically on GitHub (no developer tools on your PC)

See `BUILD-WITH-GITHUB.txt`. The included GitHub Actions workflow builds the Windows x64 VST3 and standalone target on a hosted Windows machine and uploads a downloadable ZIP artifact. You do not need to install Visual Studio, CMake, or Git locally. A GitHub account and one-time source upload are required.

## Build on Windows 10 (manual developer route)

Requirements:
- Visual Studio 2022 (Desktop development with C++)
- CMake 3.22+
- Git
- Internet access for the first configure (CMake downloads JUCE 8.0.6)

Open **x64 Native Tools Command Prompt for VS 2022** in this folder:

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

The VST3 and standalone app are produced under `build\AloTune_artefacts\Release\VST3` and `build\AloTune_artefacts\Release\Standalone` (exact intermediate layout can vary by JUCE/CMake generator). Copy the `.vst3` bundle to `C:\Program Files\Common Files\VST3`, then rescan plugins in your DAW.

## First-version limitations / notes
- This ZIP contains source code and an automated GitHub Actions build workflow, not precompiled Windows binaries. The hosted workflow has not yet been run or verified.
- Auto-root detection is intentionally basic (lowest held note); it is not a full harmonic-analysis engine and can misidentify inversions.
- The current interval table provides common 5-limit JI chromatic ratios; it is not a complete adaptive temperament solver. The `Minor` mode changes the minor-seventh ratio.
- `MPE output` uses member channels 2–16. Polyphony is limited to 15 simultaneous MPE voices.
- Pitch bend range in Vital must match the AloTune setting. With non-MPE output, notes are passed without per-note retuning because conventional MIDI pitch bend is channel-wide.
- A VST3 MIDI effect has no audio output by design. The standalone build depends on operating-system MIDI devices and may need a virtual MIDI loopback to connect to a separate synth application.

## License
Project code: MIT. JUCE is a separate dependency under its own license; see https://juce.com/legal/.
