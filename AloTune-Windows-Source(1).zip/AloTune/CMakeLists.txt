cmake_minimum_required(VERSION 3.22)
project(AloTune VERSION 0.1.0)

# JUCE is fetched at configure time. Requires an internet connection on first build.
include(FetchContent)
FetchContent_Declare(JUCE
  GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
  GIT_TAG 8.0.6
  GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(AloTune
  COMPANY_NAME "Independent Audio Tools"
  BUNDLE_ID com.independentaudiotools.alotune
  PLUGIN_MANUFACTURER_CODE IATl
  PLUGIN_CODE AlTu
  FORMATS VST3 Standalone
  PRODUCT_NAME "AloTune"
  DESCRIPTION "Adaptive Just Intonation MIDI effect"
  IS_SYNTH FALSE
  NEEDS_MIDI_INPUT TRUE
  NEEDS_MIDI_OUTPUT TRUE
  IS_MIDI_EFFECT TRUE
  EDITOR_WANTS_KEYBOARD_FOCUS TRUE
  COPY_PLUGIN_AFTER_BUILD FALSE)

juce_generate_juce_header(AloTune)
target_sources(AloTune PRIVATE
  Source/PluginProcessor.cpp
  Source/PluginProcessor.h
  Source/PluginEditor.cpp
  Source/PluginEditor.h)
target_compile_features(AloTune PRIVATE cxx_std_17)
target_compile_definitions(AloTune PUBLIC
  JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0
  JUCE_VST3_CAN_REPLACE_VST2=0)
target_link_libraries(AloTune PRIVATE
  juce::juce_audio_utils
  juce::juce_audio_processors
  juce::juce_gui_extra
  PUBLIC juce::juce_recommended_config_flags
         juce::juce_recommended_lto_flags
         juce::juce_recommended_warning_flags)
